package Dao;

import Entity.Student;

public interface DaoStudentI {
        
	 void saveData(Student s);
	
	
}
