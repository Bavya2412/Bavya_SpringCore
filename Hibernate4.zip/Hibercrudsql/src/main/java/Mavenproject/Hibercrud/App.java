package Mavenproject.Hibercrud;

/**
 * Hello world!
 *
 */

import Service.StudentService;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	StudentService service = new StudentService() ;
    	service.saveService();
    	//service.updateService();
    	//service.deleteService();

    }
}
