package Util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class Dbutil {
    private static String url;
    private static String username;
    private static String password;

    static {
        try {
            ResourceBundle rb = ResourceBundle.getBundle("db"); 
            url = rb.getString("url");
            username = rb.getString("username");
            password = rb.getString("password");
        } catch (Exception e) {
            System.out.println("Failed to load db.properties: " + e.getMessage());
        }
    }

    public static Connection getConnection() throws SQLException {
        if (url == null || username == null || password == null) {
            throw new SQLException("Database connection details not properly loaded from properties.");
        }
        return DriverManager.getConnection(url, username, password);
    }
}
