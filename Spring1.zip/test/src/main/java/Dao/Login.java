package Dao;
import java.util.List;

import Enitity.User;

public interface Login {
	boolean signUp(User user);
    String retrievePassword(int userId, String email);
    String getUserNameIfValid(int userId, String password);
    List<User> getAllUsers();
}

