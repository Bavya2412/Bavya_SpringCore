package Controller;

import Entity.Item;
import Service.ItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
//@RequestMapping("/api")
public class ItemController {

    @Autowired
    private ItemService service;

    @PostMapping("/items")
    public Item addItem(@RequestBody Item item) {
        return service.addItem(item);
    }

    @GetMapping("/items/{code}")
    public Item getItem(@PathVariable String code) {
        return service.getItemByCode(code);
    }

    @PutMapping("/items/{code}/price")
    public Item updatePrice(@PathVariable String code, @RequestParam double price) {
        return service.updatePrice(code, price);
    }

    @PostMapping("/bill")
    public Map<String, Object> generateBill(@RequestBody List<String> codes) {
        return service.generateBill(codes);
    }

    }


