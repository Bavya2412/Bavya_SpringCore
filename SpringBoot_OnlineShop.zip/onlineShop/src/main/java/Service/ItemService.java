package Service;

import Entity.Item;
import Repo.ItemRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.*;

@Service
public class ItemService {

    @Autowired
    private ItemRepo repo;

    public Item addItem(Item item) {
        return repo.save(item);
    }

    public Item getItemByCode(String code) {
        return repo.findById(code).orElseThrow(() -> new NoSuchElementException("Item not found: " + code));
    }

    public Item updatePrice(String code, double price) {
        Item item = getItemByCode(code);
        item.setPrice(price);
        return repo.save(item);
    }

    

    public Map<String, Object> generateBill(List<String> codes) {
        List<Map<String, Object>> itemList = new ArrayList<>();
        double grandTotal = 0.0;

        for (String code : codes) {
            Item item = repo.findById(code).orElse(null);
            if (item != null && item.getQuantity() > 0) {
                int qty = item.getQuantity();
                double total = qty * item.getPrice();
                Map<String, Object> itemDetails = new HashMap<>();
                itemDetails.put("code", item.getCode());
                itemDetails.put("name", item.getName());
                itemDetails.put("price", item.getPrice());
                itemDetails.put("quantity", qty);
                itemDetails.put("total", total);

                itemList.add(itemDetails);
                grandTotal += total;

               
                item.setQuantity(0);
                repo.save(item);
            }
        }

        Map<String, Object> response = new HashMap<>();
        response.put("items", itemList);
        response.put("totalAmount", grandTotal);
        response.put("message", "Bill generated successfully");

        return response;
    }

}
