package Repo;


import org.springframework.data.jpa.repository.JpaRepository;
import Entity.Item;

public interface ItemRepo extends JpaRepository<Item, String> {
}
