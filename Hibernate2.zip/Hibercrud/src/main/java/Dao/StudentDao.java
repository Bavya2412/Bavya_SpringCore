package Dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import Connection.StudentConn;
import Entity.Student;

public class StudentDao implements DaoStudentI{
	SessionFactory factory;
	
	
	
	public StudentDao() {
	
		factory=StudentConn.getSessionFactory();
	}

	
	public void removeByRoll(int rno) {
	    Session session = factory.openSession();
	    Transaction txt = session.beginTransaction();

	    Student s = session.find(Student.class, rno);

	    if (s == null) {
	        System.out.println("Not Found");
	    } else {
	        session.delete(s);
	        txt.commit(); // Important to save changes
	        System.out.println("Student deleted.");
	    }

	    session.close();
	}

	public void updateData(Student updatedStudent) {

	    Session session = factory.openSession();
	    Transaction tx = session.beginTransaction();

	    Student existingStudent = session.find(Student.class, updatedStudent.getRollno());

	    if (existingStudent == null) {
	        System.out.println("Student not found with roll no: " + updatedStudent.getRollno());
	    } else {
	        existingStudent.setName(updatedStudent.getName());
	        existingStudent.setMarks(updatedStudent.getMarks());

	        session.update(existingStudent);
	        tx.commit();
	        System.out.println("Student updated successfully.");
	    }

	    session.close();
	}

			
	public void saveData(Student s) {
		
		
		Session session=factory.openSession();
		
		Transaction txt=session.beginTransaction();
		
		session.save(s);
		txt.commit();
		
		
		
	}
}