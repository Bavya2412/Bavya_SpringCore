package Service;

import java.util.Scanner;

import Dao.StudentDao;
import Entity.Student;

public class StudentService {
Student s;
	
	
	
	StudentDao dao;
	
	Scanner sc ;

	public StudentService() {
		
		s= new Student();
		sc=new Scanner(System.in);
		dao=new StudentDao();
	}
	
	
	public void saveService() {
		
		System.out.println("Enter RollNo: ");
		s.setRollno(sc.nextInt());
		sc.nextLine();
		System.out.println("Enter Name : \n");
		s.setName(sc.nextLine());
		
		System.out.println("Enter Marks: \n");
		s.setMarks(sc.nextInt());
		
		dao.saveData(s);
	}
	public void updateService() {
	    System.out.println("Enter RollNo to update: ");
	    int roll = sc.nextInt();
	    sc.nextLine(); // consume newline

	    System.out.println("Enter New Name: ");
	    String name = sc.nextLine();

	    System.out.println("Enter New Marks: ");
	    float marks = sc.nextFloat();

	    Student s = new Student();
	    s.setRollno(roll);
	    s.setName(name);
	    s.setMarks(marks);

	    dao.updateData(s); // calling DAO method
	}
	public void deleteService() {
	    System.out.print("Enter Roll No to Delete: ");
	    int roll = sc.nextInt();
	    dao.removeByRoll(roll);
	}


	
	
	

}