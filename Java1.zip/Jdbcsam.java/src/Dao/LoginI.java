package Dao;


import Util.Dbutil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import Enitity.User;

public  class LoginI implements Login {

    @Override
    public boolean signUp(User user) {
        String sql = "INSERT INTO Login (userId, name, email, password) VALUES (?, ?, ?, ?)";
        try (Connection conn = Dbutil.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setInt(1, user.getUserId());
            pst.setString(2, user.getName());
            pst.setString(3, user.getEmail());
            pst.setString(4, user.getPassword());
            return pst.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public String retrievePassword(int userId, String email) {
        String sql = "SELECT password FROM Login WHERE userId = ? AND email = ?";
        try (Connection conn = Dbutil.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setInt(1, userId);
            pst.setString(2, email);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                return rs.getString("password");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public String getUserNameIfValid(int userId, String password) {
        String sql = "SELECT name FROM Login WHERE userId = ? AND password = ?";
        try (Connection conn = Dbutil.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setInt(1, userId);
            pst.setString(2, password);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                return rs.getString("name");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<User> getAllUsers() {
        List<User> users = new ArrayList<>();
        String sql = "SELECT userId, name FROM Login";
        try (Connection conn = Dbutil.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                users.add(new User(rs.getInt("userId"), rs.getString("name")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return users;
    }
}
