package Util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class Dbutil {

    private static String url;
    private static String username;
    private static String password;

    static {
        try {
            ResourceBundle rb = ResourceBundle.getBundle("db");
            url = rb.getString("url");
            username = rb.getString("username");
            password = rb.getString("password");
        } catch (Exception e) {
            System.out.println("Failed to load db.properties: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(url, username, password);
    }
}
