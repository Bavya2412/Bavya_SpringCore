/**
 * 
 */
/**
 * 
 */
module Jdbcsam.java {
	requires java.sql;
}