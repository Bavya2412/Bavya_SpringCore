package Main;
import Dao.*;

import Enitity.*;
import java.util.List;
import java.util.Scanner;

public class main {

    private static Login dao = new LoginI();
    private static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        while(true) {
            System.out.println("\n---- Login Management System ----");
            System.out.println("1. Sign Up");
            System.out.println("2. Forgot Password");
            System.out.println("3. Sign In");
            System.out.println("4. List All Users");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");
            int choice = Integer.parseInt(sc.nextLine());

            switch(choice) {
                case 1:
                    signUp();
                    break;
                case 2:
                    forgotPassword();
                    break;
                case 3:
                    signIn();
                    break;
                case 4:
                    listUsers();
                    break;
                case 5:
                    System.out.println("Exiting... Goodbye!");
                    System.exit(0);
                default:
                    System.out.println("Invalid option, try again.");
            }
        }
    }

    private static void signUp() {
        System.out.print("Enter User ID: ");
        int id = Integer.parseInt(sc.nextLine());
        System.out.print("Enter Name: ");
        String name = sc.nextLine();
        System.out.print("Enter Email: ");
        String email = sc.nextLine();
        System.out.print("Enter Password: ");
        String password = sc.nextLine();

        User user = new User(id, name, email, password);
        if (dao.signUp(user)) {
            System.out.println("Sign Up Successful!");
        } else {
            System.out.println("Sign Up Failed. Try again.");
        }
    }

    private static void forgotPassword() {
        System.out.print("Enter User ID: ");
        int id = Integer.parseInt(sc.nextLine());
        System.out.print("Enter Email: ");
        String email = sc.nextLine();

        String password = dao.retrievePassword(id, email);
        if (password != null) {
            System.out.println("Your Password is: " + password);
        } else {
            System.out.println("User not found or incorrect email.");
        }
    }

    private static void signIn() {
        System.out.print("Enter User ID: ");
        int id = Integer.parseInt(sc.nextLine());
        System.out.print("Enter Password: ");
        String password = sc.nextLine();

        String name = dao.getUserNameIfValid(id, password);
        if (name != null) {
            System.out.println("Welcome, " + name + "!");
        } else {
            System.out.println("Invalid credentials.");
        }
    }

    private static void listUsers() {
        List<User> users = dao.getAllUsers();
        System.out.println("Registered Users:");
        for (User u : users) {
            System.out.println("UserID: " + u.getUserId() + ", Name: " + u.getName());
        }
    }
}
