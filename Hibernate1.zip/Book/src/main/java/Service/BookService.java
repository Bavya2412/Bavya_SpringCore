package Service;

import java.util.Scanner;

import Dao.Bookdao;
import Entity.Book;

public class BookService {

	Scanner sc = new Scanner(System.in);
    Bookdao dao = new Bookdao();

    public void addBookService() {
        System.out.println("Enter Book ID: ");
        int id = sc.nextInt(); sc.nextLine();

        System.out.println("Enter Title: ");
        String title = sc.nextLine();

        System.out.println("Enter Author: ");
        String author = sc.nextLine();

        System.out.println("Enter Price: ");
        double price = sc.nextDouble();

        System.out.println("Enter Quantity: ");
        int qty = sc.nextInt();

        Book book = new Book(id, title, author, price, qty);
        dao.addBook(book);
    }

    public void updatePriceService() {
        System.out.println("Enter Book ID to update price: ");
        int id = sc.nextInt();
        System.out.println("Enter New Price: ");
        double price = sc.nextDouble();
        dao.updateBookPrice(id, price);
    }

    public void removeBookService() {
        System.out.println("Enter Book ID to delete: ");
        int id = sc.nextInt();
        dao.removeBook(id);
    }

    public void generateBillService() {
        System.out.println("Enter Book ID: ");
        int id = sc.nextInt();
        System.out.println("Enter Quantity to Buy: ");
        int qty = sc.nextInt();
        dao.generateBill(id, qty);
    }

    public void searchByIdService() {
        System.out.println("Enter Book ID to search: ");
        int id = sc.nextInt();
        dao.searchBookById(id);
    }

    public void searchByTitleService() {
        System.out.println("Enter Title to search: ");
        sc.nextLine(); 
        String title = sc.nextLine();
        dao.searchBookByTitle(title);
    }
}

