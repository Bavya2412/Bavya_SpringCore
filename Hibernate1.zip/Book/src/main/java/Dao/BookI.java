package Dao;

import Entity.Book;

public interface BookI {

	

	    void addBook(Book book);

	    void updateBookPrice(int bookId, double newPrice);

	    void removeBook(int bookId);

	    void generateBill(int bookId, int buyQuantity);

	    void searchBookById(int bookId);

	    void searchBookByTitle(String title);
	}
	










