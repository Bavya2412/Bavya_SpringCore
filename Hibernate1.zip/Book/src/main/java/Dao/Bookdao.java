package Dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import Connection.BookConn;
import Entity.Book;

public class Bookdao implements BookI {

    private SessionFactory factory;

    public Bookdao() {
        factory = BookConn.getSessionFactory();
    }

    @Override
    public void addBook(Book book) {
        Session session = factory.openSession();
        Transaction tx = session.beginTransaction();
        session.save(book);
        tx.commit();
        session.close();
        System.out.println("Book added successfully.");
    }

    @Override
    public void updateBookPrice(int bookId, double newPrice) {
        Session session = factory.openSession();
        Transaction tx = session.beginTransaction();

        Book book = session.find(Book.class, bookId);
        if (book != null) {
            book.setPrice(newPrice);
            session.update(book);
            tx.commit();
            System.out.println("Price updated.");
        } else {
            System.out.println("Book not found.");
        }

        session.close();
    }

    @Override
    public void removeBook(int bookId) {
        Session session = factory.openSession();
        Transaction tx = session.beginTransaction();

        Book book = session.find(Book.class, bookId);
        if (book != null) {
            session.delete(book);
            tx.commit();
            System.out.println("Book deleted.");
        } else {
            System.out.println("Book not found.");
        }

        session.close();
    }

    @Override
    public void generateBill(int bookId, int buyQuantity) {
        Session session = factory.openSession();

        Book book = session.find(Book.class, bookId);
        if (book != null) {
            if (book.getQuantity() >= buyQuantity) {
                double total = book.getPrice() * buyQuantity;
                System.out.println("Title: " + book.getTitle());
                System.out.println("Unit Price: ₹" + book.getPrice());
                System.out.println("Total Amount: ₹" + total);
            } else {
                System.out.println("Insufficient stock.");
            }
        } else {
            System.out.println("Book not found.");
        }

        session.close();
    }

    @Override
    public void searchBookById(int bookId) {
        Session session = factory.openSession();
        Book book = session.find(Book.class, bookId);

        if (book != null) {
            System.out.println(book);
        } else {
            System.out.println("Book not found.");
        }

        session.close();
    }

    @Override
    public void searchBookByTitle(String title) {
        Session session = factory.openSession();

        Query<Book> q = session.createQuery("from Book where title = :title", Book.class);
        q.setParameter("title", title);

        Book book = q.uniqueResult();
        if (book != null) {
            System.out.println(book);
        } else {
            System.out.println("Book not found.");
        }

        session.close();
    }
}
