package Mavenproject.Book;

import java.util.Scanner;
import Service.BookService;

public class App {
    public static void main(String[] args) {
    	 
    	        Scanner sc = new Scanner(System.in);
    	        BookService service = new BookService();
    	        int choice;

    	        do {
    	           
    	            System.out.println("1. Add New Book");
    	            System.out.println("2. Update Book Price");
    	            System.out.println("3. Remove a Book");
    	            System.out.println("4. Generate Bill");
    	            System.out.println("5. Enquire About Book by ID");
    	            System.out.println("6. Enquire About Book by Title");
    	            System.out.println("0. Exit");
    	            System.out.print("Enter your choice: ");
    	            choice = sc.nextInt();

    	            switch (choice) {
    	                case 1: 
    	                    service.addBookService(); 
    	                    break;
    	                case 2: 
    	                    service.updatePriceService(); 
    	                    break;
    	                case 3: 
    	                    service.removeBookService(); 
    	                    break;
    	                case 4: 
    	                    service.generateBillService(); 
    	                    break;
    	                case 5: 
    	                    service.searchByIdService(); 
    	                    break;
    	                case 6: 
    	                    service.searchByTitleService(); 
    	                    break;
    	                case 0: 
    	                    System.out.println("Exiting..."); 
    	                    break;
    	                default: 
    	                    System.out.println("Invalid choice!");
    	            }
    	        } while (choice != 0);

    	        sc.close();
    	    }
}
