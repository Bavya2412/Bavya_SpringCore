package java8;

public class Main {
public static void main(String[] args) {
		
		
		
		sum s= new sum();
		  int k=s.cal(20,30);
		  System.out.println(k);
		}
   
}
