package java8;

public class sum implements Calculator {
  public int cal(int a,int b) {
	  return a+b;
  }
}
