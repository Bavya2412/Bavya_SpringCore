package java8;

public interface Calculator {
//void fun1();
public int cal(int a, int b) ;
	


}
